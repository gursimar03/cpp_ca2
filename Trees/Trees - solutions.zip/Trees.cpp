// Trees.cpp : Defines the entry point for the console application.
//
#include "Tree.h"
#include "TreeIterator.h"
#include <string>
#include <iostream>
#include <queue>

using namespace std;
void displayTree(TreeIterator<string> iter, string indent)
{
	bool wasValid=false;
	cout << indent<<"(" << iter.item();
	if (iter.childValid())
	{
		wasValid = true;
		cout << endl;
	}
	else
	{
		cout << ")"<<endl;
	}
	while(iter.childValid())
	{
		TreeIterator<string> iter2(iter);
		iter2.down();
		displayTree(iter2, indent + "\t");
		iter.childForth();
	}
	if (wasValid)
	{
		cout<<indent << ")" << endl;
	}
}

void printDFS(TreeIterator<string> iter)
{
	cout << iter.item()<<"->";
	while (iter.childValid())
	{
		TreeIterator<string> iter2(iter);
		iter2.down();
		printDFS(iter2);
		iter.childForth();
	}
}

void printBFS(Tree<string> tree)
{
	queue <Tree<string>> que;
	que.push(tree);
	while (!que.empty())
	{
		cout << que.front().data<<"->" ;
		if (que.front().children->getIterator().isValid())
		{
			DListIterator<Tree<string>*> iter = que.front().children->getIterator();

			while (iter.isValid())
			{
				que.push(*iter.item());
				iter.advance();
			}
			
		}
		que.pop();
	}

}
void question1()
{
	Tree<string> *tree= new Tree<string>("Sales");
	TreeIterator<string> iter(tree);
	iter.appendChild("Domestic");
	iter.appendChild("International");
	iter. childForth();
	iter.down();
	
	iter.appendChild("Canada");
	iter.appendChild("S. America");
	iter.appendChild("Overseas");
	
	iter.childForth();
	iter.childForth();
	iter.down();
	iter.appendChild("Africa");
	iter.appendChild("Europe");
	iter.appendChild("Asia");
	iter.appendChild("Australia");
	iter.root();
	displayTree(iter,"");

}

void question2()
{
	Tree<string> *tree = new Tree<string>("Sales");
	TreeIterator<string> iter(tree);
	iter.appendChild("International");
	iter.appendChild("Domestic");
	iter.down();
	iter.appendChild("Overseas");
	iter.appendChild("Canada");
	iter.appendChild("S. America");

	iter.down();
	iter.appendChild("Africa");
	iter.appendChild("Europe");
	iter.appendChild("Asia");
	iter.appendChild("Australia");
	iter.root();
	displayTree(iter, "");
	printDFS(iter);
	cout << endl;
	printBFS(*tree);
}

int main()
{
	question1();
	question2();

    return 0;
}

